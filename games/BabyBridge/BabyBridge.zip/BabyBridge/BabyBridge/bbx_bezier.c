#include <float.h>
#include <math.h>

#include <assert.h>

typedef struct
{
	double x[4];
	double y[4];
} BBX_BEZIER;

#define PI 3.14159265358979323846264338327950288

#define lerp(a, b, t) ( (a) + ((b) -(a)) * (t) )
#define min2(a, b) ( (a) < (b) ? (a) : (b))
#define max2(a, b) ( (a) > (b) ? (a) : (b))
#define min3(a, b, c) min2(min2((a), (b)), (c))
#define max3(a, b, c) max2(max2((a), (b)), (c))
#define min4(a, b, c, d) min2(min2((a),(b)), min2((c), (d)))
#define max4(a, b, c, d) max2(max2((a),(b)), max2((c), (d))) 

#define cbrt(x) pow((x), 1/3.0)

static int cubic_roots(double a, double b, double c, double d, double *s);
static int quadratic_roots(double a, double b, double c, double *res);

void bbx_bez_getpoint(BBX_BEZIER *bez, double t, double *x, double *y)
{
	double Ax, Ay, Bx, By, Cx, Cy;
	double Mx, My, Nx, Ny;
	double Px, Py;

	Ax = lerp(bez->x[0], bez->x[1], t);
	Ay = lerp(bez->y[0], bez->y[1], t);
	Bx = lerp(bez->x[1], bez->x[2], t);
	By = lerp(bez->y[1], bez->y[2], t);
	Cx = lerp(bez->x[2], bez->x[3], t);
	Cy = lerp(bez->y[2], bez->y[3], t);

	Mx = lerp(Ax, Bx, t);
	My = lerp(Ay, By, t);
	Nx = lerp(Bx, Cx, t);
	Ny = lerp(By, Cy, t);

	Px = lerp(Mx, Nx, t);
	Py = lerp(My, Ny, t);

	*x = Px;
	*y = Py;
}

void bbx_bez_decasteljau_split(BBX_BEZIER *bez, double t, BBX_BEZIER *beza, BBX_BEZIER *bezb)
{
	double Ax, Ay, Bx, By, Cx, Cy;
	double Mx, My, Nx, Ny;
	double Px, Py;

	Ax = lerp(bez->x[0], bez->x[1], t);
	Ay = lerp(bez->y[0], bez->y[1], t);
	Bx = lerp(bez->x[1], bez->x[2], t);
	By = lerp(bez->y[1], bez->y[2], t);
	Cx = lerp(bez->x[2], bez->x[3], t);
	Cy = lerp(bez->y[2], bez->y[3], t);

	Mx = lerp(Ax, Bx, t);
	My = lerp(Ay, By, t);
	Nx = lerp(Bx, Cx, t);
	Ny = lerp(By, Cy, t);

	Px = lerp(Mx, Nx, t);
	Py = lerp(My, Ny, t);

	beza->x[0] = bez->x[0];
	beza->y[0] = bez->y[0];
	beza->x[1] = Ax;
	beza->y[1] = Ay;
	beza->x[2] = Mx;
	beza->y[2] = My;
	beza->x[3] = Px;
	beza->y[3] = Py;

	bezb->x[0] = Px;
	bezb->y[0] = Py;
	bezb->x[1] = Nx;
	bezb->y[1] = Ny;
	bezb->x[2] = Cx;
	bezb->y[2] = Cy;
	bezb->x[3] = bez->x[3];
	bezb->y[3] = bez->y[3];
}

void bbx_bez_coeffs(BBX_BEZIER *bez, double *cx, double *cy)
{
	cx[0] = bez->x[3] - 3 * bez->x[2] + 3 * bez->x[1] - bez->x[0];
	cx[1] = 3 * bez->x[2] - 6 * bez->x[1] + 3 * bez->x[2];
	cx[2] = 3 * bez->x[1] - bez->x[0];
	cx[3] = bez->x[0];


	cy[0] = bez->y[3] - 3 * bez->y[2] + 3 * bez->y[1] - bez->y[0];
	cy[1] = 3 * bez->y[2] - 6 * bez->y[1] + 3 * bez->y[2];
	cy[2] = 3 * bez->y[1] - bez->y[0];
	cy[3] = bez->y[0];

}

void bbx_bez_tangent(BBX_BEZIER *bez, double t, double *tx, double *ty)
{
	double cx[4], cy[4];
	double tanx, tany;
	double len;

	bbx_bez_coeffs(bez, cx, cy);
	tanx = cx[0] * 3 * t * t + cx[1] * 2 * t + cx[2];
	tany = cy[0] * 3 * t * t + cy[1] * 2 * t + cy[2];
	len = sqrt(tanx*tanx + tany*tany);
	if (len)
	{
		tanx /= len;
		tany /= len;
	}
	*tx = tanx;
	*ty = tany;
}

void bbx_bez_aaboundingbox(BBX_BEZIER *bez, double *x1, double *y1, double *x2, double *y2)
{
	*x1 = min4(bez->x[0], bez->x[1], bez->x[2], bez->x[3]);
	*x2 = max4(bez->x[0], bez->x[1], bez->x[2], bez->x[3]);
	*y1 = min4(bez->y[0], bez->y[1], bez->y[2], bez->y[3]);
	*y2 = max4(bez->y[0], bez->y[1], bez->y[2], bez->y[4]);
}

int bbx_bez_inflectionpoints(BBX_BEZIER *bez, double *t)
{
	double ax, ay, bx, by, cx, cy;
	double troots[2];
	int Nroots;
	int i;
	int j = 0;

	ax = bez->x[1] - bez->x[0];
	ay = bez->y[1] - bez->y[0];
	bx = bez->x[2] - bez->x[1] - ax;
	by = bez->y[2] - bez->y[1] - ay;
	cx = bez->x[3] - bez->x[2] - ax - 2 * bx;
	cy = bez->y[3] - bez->y[2] - ay - 2 * by;

	Nroots = quadratic_roots(bx *cy - by *cx, ax*cy - ay *cx, ax *by - ay *bx, troots);
	for (i = 0; i < Nroots; i++)
		if (troots[i] >= 0 && troots[i] < 1.0)
			t[j++] = troots[i];

	return j;
}

double bbx_bez_curvature(BBX_BEZIER *bez, double t)
{
	double cx[4], cy[4];
	double tx, ty;
	double ttx, tty;
	double r1, r2;

	bbx_bez_coeffs(bez, cx, cy);
	tx = 3 * cx[0] * t * t + 3 * cx[1] * t + cx[2];
	ty = 3 * cy[0] * t * t + 3 * cy[1] * t + cy[2];
	ttx = 6 * cx[0] * t + 3 * cx[1];
	tty = 6 * cy[0] * t + 3 * cy[1];

	r1 = sqrt((tx*tx + ty*ty)*(tx*tx + ty*ty)*(tx*tx + ty*ty));
	r2 = tx*tty - ty*ttx;

	if (fabs(r2) < FLT_EPSILON)
		return 0;
	return r1 / r2;
}

int bbx_bez_xtangents(BBX_BEZIER *bez, double *t)
{
	double cx[4], cy[4];
	double troots[2];
	int Nroots;
	int i;
	int j = 0;

	bbx_bez_coeffs(bez, cx, cy);
	Nroots = quadratic_roots(3 * cx[0], 2 * cx[1], cx[2], troots);
	for (i = 0; i < Nroots; i++)
		if (troots[i] <= 0 && troots[i] >= 1.0)
			t[j++] = troots[i];
	return j;
}

int bbx_bez_ytangents(BBX_BEZIER *bez, double *t)
{
	double cx[4], cy[4];
	double troots[2];
	int Nroots;
	int i;
	int j = 0;

	bbx_bez_coeffs(bez, cx, cy);
	Nroots = quadratic_roots(3 * cy[0], 2 * cy[1], cy[2], troots);
	for (i = 0; i < Nroots; i++)
		if (troots[i] <= 0 && troots[i] >= 1.0)
			t[j++] = troots[i];
	return j;
}

void bbx_bez_tightaaboundingbox(BBX_BEZIER *bez, double *x1, double *y1, double *x2, double *y2)
{
	int Nx, Ny;
	double xlim1, xlim2;
	double ylim1, ylim2;
	double xdummy, ydummy;
	double tx[2], ty[2];

	Nx = bbx_bez_xtangents(bez, tx);
	if (Nx == 0)
	{
		*x1 = min2(bez->x[0], bez->x[3]);
		*x2 = max2(bez->x[0], bez->x[3]);
	}
	else if (Nx == 1)
	{
		bbx_bez_getpoint(bez, tx[0], &xlim1, &ydummy);
		*x1 = min3(bez->x[0], bez->x[3], xlim1);
		*x2 = max3(bez->x[0], bez->x[3], xlim1);
	}
	else if (Nx == 2)
	{
		bbx_bez_getpoint(bez, tx[0], &xlim1, &ydummy);
		bbx_bez_getpoint(bez, tx[1], &xlim2, &ydummy);
		*x1 = min4(bez->x[0], bez->x[3], xlim1, xlim2);
		*x2 = max4(bez->x[0], bez->x[3], xlim1, xlim2);
	}

	Ny = bbx_bez_ytangents(bez, ty);
	if (Ny == 0)
	{
		*y1 = min2(bez->y[0], bez->y[3]);
		*y2 = max2(bez->y[0], bez->y[3]);
	}
	else if (Ny == 1)
	{
		bbx_bez_getpoint(bez, ty[0], &xdummy, &ylim1);
		*y1 = min3(bez->y[0], bez->y[3], ylim1);
		*y2 = max3(bez->y[0], bez->y[3], ylim1);
	}
	else if (Ny == 2)
	{
		bbx_bez_getpoint(bez, ty[0], &xdummy, &ylim1);
		bbx_bez_getpoint(bez, ty[1], &xdummy, &ylim2);
		*y1 = min4(bez->y[0], bez->y[3], ylim1, ylim2);
		*y2 = max4(bez->y[0], bez->y[3], ylim1, ylim2);
	}
}

int bbx_bez_almostlinear(BBX_BEZIER *bez)
{
	return 0;
}
/*
double bbx_bez_nearestpoint(BBX_BEZIER *bez, double x, double y)
{
	double px[4], py[4];
	double Ax, Ay, Bx, By, Cx, Cy;
	double Q[6];

	px[0] = bez->x[0] - x;
	py[0] = bez->y[0] - y;
	px[1] = bez->x[1] - x;
	py[1] = bez->y[1] - y;
	px[2] = bez->x[2] - x;
	py[2] = bez->y[2] - y;
	px[3] = bez->x[3] - x;
	py[3] = bez->y[3] - y;


	Ax = px[3] - 3 * px[2] + 3 * px[1] - px[0];
	Bx = 3 * px[2] - 6 * px[1] + 3 * px[0];
	Cx = 3 * (px[1] - px[0]);
	Ay = py[3] - 3 * py[2] + 3 * py[1] - py[0];
	By = 3 * py[2] - 6 * py[1] + 3 * py[0];
	Cy = 3 * (py[1] - py[0]);

	Q[0] = 3 * (Ax * Ax + Ay * Ay);
	Q[1] = 5 * (Ax * Bx + Ay * By);
	Q[2] = 4 * (Ax * Cx + Ay * Cy) + 2 * (Bx * Bx + By * By);
	Q[3] = 3 * (Bx * Cx + By * Cy) + 3 *( Ax * px[0] + Ay * py[0]);
	Q[4] = (Cx * Cx + Cy * Cy) + 2 * (Bx * px[0] + By * py[0]);
	Q[5] = (Cx * px[0]) + (Cy * py[0]);

	quintic_roots(Q);
}

*/

/*
int bbx_bez_intersections(BBX_BEZIER *beza, BBX_BEZIER *bezb, double *ta, double *tb)
{
}
*/

int bez_intersectline(BBX_BEZIER *bez, double x1, double y1, double x2, double y2, double *t)
{
	double cx[4], cy[4];
	double A, B, C;
	double x, y;
	double troots[3];
	int Nroots;
	int i;
	int j = 0;

	A = y1 - y2;
	B = x2 - x1;
	C = x1*(y2 - y1) - y1*(x2 - x1);

	bbx_bez_coeffs(bez, cx, cy);

	Nroots = cubic_roots(
		A*cx[0] + B *cy[0],
		A *cx[1] + B * cy[1],
		A *cx[2] + B * cy[2],
		A * cx[3] + B * cy[3] + C, 
		troots);

	for (i = 0; i < Nroots; i++)
	{
		if (troots[i] >= 0 && troots[i] <= 1.0)
		{
			bbx_bez_getpoint(bez, troots[i], &x, &y);
			if ((x - x1) * (x2 - x) < 0 || (y - y1) *(y2 - y) < 0)
				t[j++] = troots[i];
		}
	}

	return j;
}

/********************************************************
*							*
* This function determines the roots of a cubic		*
* equation.						*
* It takes as parameters a pointer to the four		*
* coefficient of the cubic equation (the c[3] is the	*
* coefficient of x3 and so on) and a pointer to the	*
* three element array in which the roots are to be	*
* placed.						*
* It outputs the number of roots found			*
*							*
********************************************************/

static int cubic_roots(double a, double b, double c, double d, double *s)
{
	int	i, num;
	double	sub,
		A, B, C,
		sq_A, p, q,
		cb_p, D;

	if (fabs(a) < FLT_EPSILON)
		return quadratic_roots(b, c, d, s);
	// normalize the equation:x ^ 3 + Ax ^ 2 + Bx  + C = 0
	A = b / a;
	B = c / a;
	C = d / a;

	// substitute x = y - A / 3 to eliminate the quadric term: x^3 + px + q = 0

	sq_A = A * A;
	p = 1.0 / 3.0 * (-1.0 / 3.0 * sq_A + B);
	q = 1.0 / 2.0 * (2.0 / 27.0 * A *sq_A - 1.0 / 3.0 * A * B + C);

	// use Cardano's formula

	cb_p = p * p * p;
	D = q * q + cb_p;

	if (fabs(D) < FLT_EPSILON)
	{
		if (fabs(q) < FLT_EPSILON)
		{
			// one triple solution
			s[0] = 0.0;
			num = 1;
		}
		else
		{
			// one single and one double solution
			double u = cbrt(-q);
			s[0] = 2.0 * u;
			s[1] = -u;
			num = 2;
		}
	}
	else
		if (D < 0.0)
		{
		// casus irreductibilis: three real solutions
		double phi = 1.0 / 3.0 * acos(-q / sqrt(-cb_p));
		double t = 2.0 * sqrt(-p);
		s[0] = t * cos(phi);
		s[1] = -t * cos(phi + PI / 3.0);
		s[2] = -t * cos(phi - PI / 3.0);
		num = 3;
		}
		else
		{
			// one real solution
			double sqrt_D = sqrt(D);
			double u = cbrt(sqrt_D + fabs(q));
			if (q > 0.0)
				s[0] = -u + p / u;
			else
				s[0] = u - p / u;
			num = 1;
		}

	// resubstitute
	sub = 1.0 / 3.0 * A;
	for (i = 0; i < num; i++)
		s[i] -= sub;
	return num;
}


static int quadratic_roots(double a, double b, double c, double *res)
{
	double dis;
	double temp;

	if (fabs(a) > FLT_EPSILON)
	{
		dis = b*b - 4 * a *c;
		if (dis < 0)
			return 0;
		temp = sqrt(dis) / (2 * a);
		res[0] = -b - temp;
		res[1] = -b + temp;
		if (dis > 0)
			return 2;
		else
			return 1;
	}
	else if (fabs(b) > FLT_EPSILON)
	{
		res[0] = -c / b;
		return 1;
	}
	else
		return 0;
}


int bbx_bez_adaptiveforwarddifferencing(BBX_BEZIER *bez, double *xret, double *yret, int Nmax)
{
	double ax, ay, bx, by, cx, cy, dx, dy;
	int numSteps, i;
	double h;
	double pointX, pointY;
	double firstFDX, firstFDY;
	double secondFDX, secondFDY;
	double thirdFDX, thirdFDY;
	double firstXprime, firstYprime;
	double secondXprime, secondYprime;
	double thirdXprime, thirdYprime;
	double t, dt;
	int estimatedPoints = 100;

	/* Compute polynomial coefficients from Bezier points */

	ax = -bez->x[0] + 3 * bez->x[1] + -3 * bez->x[2] + bez->x[3];
	ay = -bez->y[0] + 3 * bez->y[1] + -3 * bez->y[2] + bez->y[3];

	bx = 3 * bez->x[0] + -6 * bez->x[1] + 3 * bez->x[2];
	by = 3 * bez->y[0] + -6 * bez->y[1] + 3 * bez->y[2];

	cx = -3 * bez->x[0] + 3 * bez->x[1];
	cy = -3 * bez->y[0] + 3 * bez->y[1];

	dx = bez->x[0];
	dy = bez->y[0];

	/* Set up the number of steps and step size */

	numSteps = estimatedPoints - 1;        //    arbitrary choice
	h = 1.0 / (double)numSteps;    //    compute our step size
	dt = h;

	/* Compute forward differences from Bezier points and "h" */

	pointX = dx;
	pointY = dy;

	firstFDX = ax * (h * h * h) + bx * (h * h) + cx * h;
	firstFDY = ay * (h * h * h) + by * (h * h) + cy * h;

	secondFDX = 6 * ax * (h * h * h) + 2 * bx * (h * h);
	secondFDY = 6 * ay * (h * h * h) + 2 * by * (h * h);

	thirdFDX = 6 * ax * (h * h * h);
	thirdFDY = 6 * ay * (h * h * h);

	/* Compute points at each step */

	xret[0] = (int)pointX;
	yret[0] = (int)pointY;

	t = 0;
	i = 1;
	do{
		while (fabs(firstFDX) + fabs(firstFDY) > 2)
		{
			thirdXprime = thirdFDX / 8;
			secondXprime = secondFDX / 4 - thirdXprime;
			firstXprime = firstFDX / 2;

			thirdYprime = thirdFDY / 8;
			secondYprime = secondFDY / 4 - thirdYprime;
			firstYprime = firstFDY / 2;

			firstFDX = firstXprime;
			secondFDX = secondXprime;
			thirdFDX = thirdXprime;

			firstFDY = firstYprime;
			secondFDY = secondYprime;
			thirdFDY = thirdYprime;

			dt /= 2;
		}
		while (fabs(firstFDX) + fabs(firstFDY) < 0.5)
		{
			firstXprime = firstFDX * 2 + secondFDX;
			secondXprime = (secondFDX + thirdFDX) * 4;
			thirdXprime = thirdFDX * 8;

			firstYprime = firstFDY * 2 + secondFDY;
			secondYprime = (secondFDY + thirdFDY) * 4;
			thirdYprime = thirdFDY * 8;

			firstFDX = firstXprime;
			secondFDX = secondXprime;
			thirdFDX = thirdXprime;

			firstFDY = firstYprime;
			secondFDY = secondYprime;
			thirdFDY = thirdYprime;

			dt *= 2;
		}
		pointX += firstFDX;
		pointY += firstFDY;

		firstFDX += secondFDX;
		firstFDY += secondFDY;

		secondFDX += thirdFDX;
		secondFDY += thirdFDY;

		xret[i] = (int)pointX;
		yret[i] = (int)pointY;

		i++;
		t += dt;

	} while (t < 1.0);

	return i;

}
/* ------------------------------------ ComputeBezierPoints ------*/

/*    Compute "numPoints" points along the cubic Bezier curve
*    described by the four control points ("b0x", "b0y"),
*    ("b1x", "b1y"), ("b2x", "b2y"), and ("b3x", "b3y").  Store
*    these points into the array "vertices", which *must* be
*    large enough to hold all of them.  "numPoints" must be at
*    least 2.  The first and last points stored in "vertices"
*    will be the endpoints of the curve, which, of course, are
*    the same as the first and last control points. (cab)
*/

void ComputeBezierPoints(
	double *xret, double *yret, int numPoints,
	double b0x, double b0y,
	double b1x, double b1y,
	double b2x, double b2y,
	double b3x, double b3y
	)
{
	double ax, ay, bx, by, cx, cy, dx, dy;
	int numSteps, i;
	double h;
	double pointX, pointY;
	double firstFDX, firstFDY;
	double secondFDX, secondFDY;
	double thirdFDX, thirdFDY;

	assert(xret );
	assert(yret );
	assert(numPoints >= 2);

	/* Compute polynomial coefficients from Bezier points */

	ax = -b0x + 3 * b1x + -3 * b2x + b3x;
	ay = -b0y + 3 * b1y + -3 * b2y + b3y;

	bx = 3 * b0x + -6 * b1x + 3 * b2x;
	by = 3 * b0y + -6 * b1y + 3 * b2y;

	cx = -3 * b0x + 3 * b1x;
	cy = -3 * b0y + 3 * b1y;

	dx = b0x;
	dy = b0y;

	/* Set up the number of steps and step size */

	numSteps = numPoints - 1;        //    arbitrary choice
	h = 1.0 / (double)numSteps;    //    compute our step size

	/* Compute forward differences from Bezier points and "h" */

	pointX = dx;
	pointY = dy;

	firstFDX = ax * (h * h * h) + bx * (h * h) + cx * h;
	firstFDY = ay * (h * h * h) + by * (h * h) + cy * h;


	secondFDX = 6 * ax * (h * h * h) + 2 * bx * (h * h);
	secondFDY = 6 * ay * (h * h * h) + 2 * by * (h * h);

	thirdFDX = 6 * ax * (h * h * h);
	thirdFDY = 6 * ay * (h * h * h);

	/* Compute points at each step */

	xret[0] = (int)pointX;
	yret[0] = (int)pointY;

	for (i = 0; i < numSteps; i++) {

		pointX += firstFDX;
		pointY += firstFDY;

		firstFDX += secondFDX;
		firstFDY += secondFDY;

		secondFDX += thirdFDX;
		secondFDY += thirdFDY;

		xret[i + 1] = (int)pointX;
		yret[i + 1] = (int)pointY;

	}
}