#ifndef bbx_bezier_h
#define bbx_bezier_h

typedef struct
{
	double x[4];
	double y[4];
} BBX_BEZIER;

void bbx_bez_decasteljau_split(BBX_BEZIER *bez, double t, BBX_BEZIER *beza, BBX_BEZIER *bezb);
void bbx_bez_aaboundingbox(BBX_BEZIER *bez, double *x1, double *y1, double *x2, double *y2);

#endif

