#ifndef cardpic_h
#define cardpic_h

unsigned char *card_rgba(CARD *card, int *width, int *height);

#endif
