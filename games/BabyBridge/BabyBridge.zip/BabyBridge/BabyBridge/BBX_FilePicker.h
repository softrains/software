#ifndef bbx_filepicker_h
#define bbx_filepicker_h

char *bbx_getopenfile(BABYX *bbx, char *filt);
char *bbx_getsavefile(BABYX *bbx, char *filt);

#endif
