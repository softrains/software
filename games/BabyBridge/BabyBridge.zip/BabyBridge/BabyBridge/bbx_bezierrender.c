
#include "BBX_Color.h"
#include "bbx_graphicssupport.h"
#include "bbx_bezier.h"

int bbx_drawbezier(unsigned char *rgba, int width, int height, BBX_BEZIER *bez, BBX_RGBA col)
{
	int red, green, blue, alpha;
	double x1, y1, x2, y2;
	int offset;
	BBX_BEZIER beza, bezb;

	bbx_bez_aaboundingbox(bez, &x1, &y1, &x2, &y2);

	if (x1 > width - 1 || x2 < 0 || y1 > height - 1 || y2 < 0)
		return -1;
	if (x2 - x1 < 0.5 && y2 - y1 < 0.5)
	{
		red = bbx_red(col);
		green = bbx_green(col);
		blue = bbx_blue(col);
		alpha = bbx_alpha(col);
		offset = (((int)y1) * width + (int) x1) * 4;

		rgba[offset + 0] = red;
		rgba[offset + 1] = green;
		rgba[offset + 2] = blue;
		rgba[offset + 3] = 255;
	}
	else
	{
		bbx_bez_decasteljau_split(bez, 0.5, &beza, &bezb);
		bbx_drawbezier(rgba, width, height, &beza, col);
		bbx_drawbezier(rgba, width, height, &bezb, col);
	}

	return 0;
}