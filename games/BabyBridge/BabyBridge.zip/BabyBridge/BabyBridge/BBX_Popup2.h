#ifndef bbx_popup2_h
#define bbx_popup2_h

int bbx_quickpopup(BABYX *bbx, BBX_Panel *parent, int x, int y, char **str, int N);

#endif
